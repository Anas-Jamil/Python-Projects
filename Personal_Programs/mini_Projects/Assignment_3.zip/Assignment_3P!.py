# Anas Jamil (668659)
# 2020-10-29
# Draw a playing card with the Rank, Colour and Suit. Ask user if it would like to roll.
import random
def Rank_Of_Card():
# This finds the rank of the card or the number
    import random
    Total_Card_Rank = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]
    Card_Rank = random.choice(Total_Card_Rank)
    return Card_Rank,
# returns Card rank to other functions
def Suit_Of_Card():
# Finds the Suit of the card. ex. Spades
    Total_Suits = ["Spades", "Hearts", "Club", "Diamond"]
    Rank_Of_Suit = random.choice(Total_Suits)
    return Rank_Of_Suit,

def Colour_Of_Card():
# Finds the colour of the card including the Suit. Spades = Black
    Rank_Of_Suit, = Suit_Of_Card()
    if Rank_Of_Suit == "Spades" or "Clubs":
        Colour_Card = "Black"
    else:
        Colour_Card = "Red"
    
    return Colour_Card,
         
def Main_Program():
#This is the main program, missing the while loop somewhere to make it ask for input again. 
    Card_Rank, = Rank_Of_Card()
    Rank_Of_Suit, = Suit_Of_Card()
    Colour_Card, = Colour_Of_Card()
    User_Input = str(input("Type Yes to draw a card: "))
    if User_Input == "Yes" or "yes":
        Rank_Of_Card()
        Suit_Of_Card()
        Colour_Of_Card()
        print ("You got a", Colour_Card, Card_Rank, "of", Rank_Of_Suit)

Main_Program()
                    
                    
                    
                    
            
            
    


    

        